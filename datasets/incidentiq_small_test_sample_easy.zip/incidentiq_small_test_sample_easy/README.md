# Small Test Sample Easy

Tiny blind runtime logs with four obvious incidents. Runtime should read only raw_logs/. Labels are isolated under ground_truth_eval_only/.
